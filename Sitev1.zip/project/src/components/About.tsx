import { motion } from 'framer-motion';
import { Heart, Users, Trophy, Lightbulb } from 'lucide-react';

const features = [
  {
    icon: Heart,
    title: 'Paixão',
    description: 'Dedicação total a cada detalhe do seu evento'
  },
  {
    icon: Users,
    title: 'Equipa Experiente',
    description: 'Profissionais qualificados com anos de experiência'
  },
  {
    icon: Trophy,
    title: 'Excelência',
    description: 'Compromisso com a qualidade em todos os projetos'
  },
  {
    icon: Lightbulb,
    title: 'Criatividade',
    description: 'Soluções inovadoras para eventos memoráveis'
  }
];

export default function About() {
  return (
    <section id="about" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl font-bold text-gray-900 mb-4">
            Sobre Nós
          </h2>
          <div className="w-24 h-1 bg-[#C41E3A] mx-auto mb-6"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            A Invert Eventos é especializada na criação e gestão de eventos únicos,
            desde pequenas reuniões até grandes festivais de música. Com foco na
            excelência e inovação, transformamos cada evento numa experiência memorável.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -10, transition: { duration: 0.3 } }}
              className="group"
            >
              <div className="bg-gray-50 rounded-xl p-8 h-full transition-all duration-300 hover:shadow-xl hover:shadow-[#C41E3A]/10">
                <motion.div
                  whileHover={{ rotate: 360 }}
                  transition={{ duration: 0.6 }}
                  className="w-16 h-16 bg-gradient-to-br from-[#C41E3A] to-[#A01828] rounded-lg flex items-center justify-center mb-6 group-hover:shadow-lg group-hover:shadow-[#C41E3A]/50 transition-all"
                >
                  <feature.icon className="w-8 h-8 text-white" />
                </motion.div>
                <h3 className="text-2xl font-bold text-gray-900 mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
