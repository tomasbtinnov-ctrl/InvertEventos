import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Maria Silva',
    role: 'CEO, Tech Solutions',
    text: 'A Invert Eventos organizou o nosso evento corporativo de forma impecável. Profissionalismo e atenção aos detalhes excepcionais!',
    rating: 5
  },
  {
    name: 'João Santos',
    role: 'Noivo',
    text: 'O nosso casamento foi um sonho tornado realidade. Cada detalhe foi cuidadosamente planeado e executado. Recomendamos sem hesitação!',
    rating: 5
  },
  {
    name: 'Ana Costa',
    role: 'Organizadora de Festival',
    text: 'Trabalhamos com a Invert em vários festivais de música. A equipa é experiente, criativa e sempre entrega resultados extraordinários.',
    rating: 5
  }
];

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl font-bold text-gray-900 mb-4">
            Testemunhos
          </h2>
          <div className="w-24 h-1 bg-[#C41E3A] mx-auto mb-6"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            O que os nossos clientes dizem sobre nós
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              whileHover={{ y: -10 }}
              className="group"
            >
              <div className="bg-gray-50 rounded-2xl p-8 h-full relative hover:shadow-2xl transition-all duration-300">
                <motion.div
                  initial={{ scale: 1 }}
                  whileHover={{ scale: 1.1, rotate: 180 }}
                  transition={{ duration: 0.4 }}
                  className="absolute -top-4 -right-4 w-16 h-16 bg-[#C41E3A] rounded-full flex items-center justify-center shadow-lg"
                >
                  <Quote className="w-8 h-8 text-white" />
                </motion.div>

                <div className="flex gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-[#C41E3A] text-[#C41E3A]" />
                  ))}
                </div>

                <p className="text-gray-700 leading-relaxed mb-6 italic">
                  "{testimonial.text}"
                </p>

                <div className="border-t border-gray-200 pt-6">
                  <p className="font-bold text-gray-900 text-lg">
                    {testimonial.name}
                  </p>
                  <p className="text-gray-600 text-sm">
                    {testimonial.role}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
