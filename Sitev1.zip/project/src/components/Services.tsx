import { motion } from 'framer-motion';
import { Briefcase, Heart, Music2, PartyPopper, Users } from 'lucide-react';

const services = [
  {
    icon: Briefcase,
    title: 'Eventos Corporativos',
    description: 'Conferências, seminários, team building e eventos empresariais personalizados',
    gradient: 'from-blue-500 to-blue-700'
  },
  {
    icon: Heart,
    title: 'Casamentos',
    description: 'Do planeamento à execução, tornamos o vosso dia especial inesquecível',
    gradient: 'from-pink-500 to-rose-600'
  },
  {
    icon: Music2,
    title: 'Concertos',
    description: 'Produção completa de concertos e espetáculos musicais de qualquer dimensão',
    gradient: 'from-purple-500 to-indigo-600'
  },
  {
    icon: PartyPopper,
    title: 'Festivais',
    description: 'Gestão e produção de festivais de música e eventos em grande escala',
    gradient: 'from-orange-500 to-red-600'
  },
  {
    icon: Users,
    title: 'Festas Privadas',
    description: 'Aniversários, celebrações e eventos sociais com toque personalizado',
    gradient: 'from-green-500 to-emerald-600'
  }
];

export default function Services() {
  return (
    <section id="services" className="py-24 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl font-bold text-gray-900 mb-4">
            Nossos Serviços
          </h2>
          <div className="w-24 h-1 bg-[#C41E3A] mx-auto mb-6"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Soluções completas para todo tipo de evento, com profissionalismo e dedicação
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="group relative"
            >
              <div className="bg-white rounded-2xl p-8 h-full shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100">
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ duration: 0.3 }}
                  className={`w-20 h-20 bg-gradient-to-br ${service.gradient} rounded-xl flex items-center justify-center mb-6 shadow-lg`}
                >
                  <service.icon className="w-10 h-10 text-white" />
                </motion.div>

                <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-[#C41E3A] transition-colors">
                  {service.title}
                </h3>

                <p className="text-gray-600 leading-relaxed">
                  {service.description}
                </p>

                <motion.div
                  className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-[#C41E3A] to-[#A01828]"
                  initial={{ scaleX: 0 }}
                  whileHover={{ scaleX: 1 }}
                  transition={{ duration: 0.3 }}
                />
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
