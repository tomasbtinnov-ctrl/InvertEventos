import { motion } from 'framer-motion';
import { Music, Mail, Phone, MapPin } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="flex items-center gap-2 mb-4">
              <Music className="w-8 h-8 text-[#C41E3A]" />
              <h3 className="text-2xl font-bold">Invert Eventos</h3>
            </div>
            <p className="text-gray-400 leading-relaxed">
              Especialistas em criar experiências memoráveis através de eventos únicos e personalizados.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <h4 className="text-lg font-semibold mb-4">Links Rápidos</h4>
            <ul className="space-y-2">
              <li>
                <a href="#about" className="text-gray-400 hover:text-[#C41E3A] transition-colors">
                  Sobre Nós
                </a>
              </li>
              <li>
                <a href="#services" className="text-gray-400 hover:text-[#C41E3A] transition-colors">
                  Serviços
                </a>
              </li>
              <li>
                <a href="#gallery" className="text-gray-400 hover:text-[#C41E3A] transition-colors">
                  Galeria
                </a>
              </li>
              <li>
                <a href="#contact" className="text-gray-400 hover:text-[#C41E3A] transition-colors">
                  Contacto
                </a>
              </li>
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h4 className="text-lg font-semibold mb-4">Contacto</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-[#C41E3A] mt-0.5 flex-shrink-0" />
                <a href="mailto:geral@inverteventos.pt" className="text-gray-400 hover:text-[#C41E3A] transition-colors">
                  geral@inverteventos.pt
                </a>
              </li>
              <li className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-[#C41E3A] mt-0.5 flex-shrink-0" />
                <a href="tel:+351925637187" className="text-gray-400 hover:text-[#C41E3A] transition-colors">
                  +351 925 637 187
                </a>
              </li>
              <li className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[#C41E3A] mt-0.5 flex-shrink-0" />
                <span className="text-gray-400 text-sm">
                  Estrada Camarária Cachoeiras - Cadafais, Nº 22<br />
                  Casal da Mó, 2600-581 Cachoeiras
                </span>
              </li>
            </ul>
          </motion.div>
        </div>

        <div className="border-t border-gray-800 pt-8">
          <p className="text-center text-gray-400 text-sm">
            © {new Date().getFullYear()} Invert Eventos. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}
